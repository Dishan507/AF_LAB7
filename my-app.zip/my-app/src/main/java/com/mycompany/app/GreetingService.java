package com.mycompany.app;
import com.mycompany.app.Greeting;

public interface GreetingService {

   Greeting generateMessage(String name);
}

